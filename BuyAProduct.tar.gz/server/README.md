# ng-fullstack-app
[![Build Status](https://secure.travis-ci.org/user.name/ng-fullstack-app.png?branch=master)](https://travis-ci.org/user.name/ng-fullstack-app)
[![Coverage Status](https://coveralls.io/repos/user.name/ng-fullstack-app/badge.svg?branch=master)](https://coveralls.io/r/user.name/ng-fullstack-app/?branch=master)
