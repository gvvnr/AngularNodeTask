"use strict";

require('babel-core/register');
require('babel-regenerator-runtime');

require('./server');
