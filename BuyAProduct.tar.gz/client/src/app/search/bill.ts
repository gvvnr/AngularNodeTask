export class Bill{
  purchasedBy: string;
  purchasedOn:string;
  listOfItems:string;
  itemsTotalCost:number;
}
