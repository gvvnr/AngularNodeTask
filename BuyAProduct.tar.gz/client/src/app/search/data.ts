export class ItemData {

  product_id : number;
  quantity: number;
  totalCost: number;
  cost:number;
  itemName:string;
  itemCount:number;
}
